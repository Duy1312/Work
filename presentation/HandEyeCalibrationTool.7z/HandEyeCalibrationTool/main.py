import sys
import datetime
sys.path.append("libs/")

from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QMessageBox, QAction, QMenu, QLabel, QProgressBar, QWidget
from PyQt5.QtCore import pyqtSignal, Qt, QTimer
from PyQt5.QtGui import QCursor

from ui.main_ui import Ui_MainWindow
from libs.calib import *
from libs.ui_utils import *
from libs import resources
from libs.ui_utils import ndarray2pixmap
from libs.canvas import Canvas, WindowCanvas
from libs.logger import Logger

from cameras import HIK, SODA, Webcam, base_camera, get_camera_devices

import threading
import time
import os
import json

from libs.client import VsClient

base_camera.BaseCamera._BaseCamera__MODEL_NAMES.append("MV-CE200-10UC")

VERSION = f"1.0.0 20241222.0755"

STEP_MOVE = "STEP_MOVE"
STEP_WAIT_MOVING = "STEP_WAIT_MOVING"
STEP_GET_POSE = "STEP_GET_POSE"
STEP_ERROR = "STEP_ERROR"
STEP_CALCULATE_MATRIX = "STEP_CALCULATE_MATRIX"


os.makedirs("log", exist_ok=True)
logger = Logger("logs", "log/log.log")


class MainWindow(QMainWindow):
    showResultSignal = pyqtSignal(RESULTCORNERS)
    showImageSignal = pyqtSignal(np.ndarray)
    updateRowSignal = pyqtSignal(int, tuple)
    showEffectSignal = pyqtSignal(int)
    hideEffectSignal = pyqtSignal(int)
    updatePoseSignal = pyqtSignal(int, tuple)
    logErrorSignal = pyqtSignal(str)
    logInfoSignal = pyqtSignal(str)
    logWarningSignal = pyqtSignal(str)
    showMessageBoxWarningSignal = pyqtSignal(str)
    showMessageQuestionSignal = pyqtSignal(str)
    
    def __init__(self, parent=None):
        super().__init__(parent)
    
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.camera: HIK = None
        self.mat = None
        self.count_pose = 0
        self.n_poses = 5
        self.b_message_box = None
        self.event_show = threading.Event()
        self.event_stop_live = threading.Event()
        self.event_stop_progress = threading.Event()
        self.result: RESULTCORNERS = None
        self.calib_utils: CalibUtils = None
        self.client: VsClient = None
        self.init_ui()
        self.load_config("res/config.json")
        self.init_calib()
        self.open_camera()
        self.connect_to_robot()

    def init_calib(self):
        config = self.get_config()

        board_size = tuple(map(int, config.get("Calibration", {}).get("board_size", "6,8").split(",")))
        square_size = int(config.get("Calibration", {}).get("square_size", "25"))
        type = config.get("Calibration", {}).get("calib_type", "EyeToHand")

        self.calib_utils = CalibUtils(board_size=board_size, 
                                      square_size=square_size,
                                      type=type)
        
        self.calib_utils.infoSignal.connect(self.logInfoSignal.emit)
        self.calib_utils.errorSignal.connect(self.logErrorSignal.emit)
        self.calib_utils.stepSignal.connect(self.on_step_calib)
        self.calib_utils.startSignal.connect(self.on_start_calib)
        self.calib_utils.finishedSignal.connect(self.on_finished_calib)

        err = self.calib_utils.load("data/camera_matrix.pkl")
        if err:
            msg = f"Load camera matrix error: {err}"
            self.logErrorSignal.emit(msg)
            logger.error(msg)
        else:
            msg = "Load camera matrix success"
            self.logInfoSignal.emit(msg)
            logger.info(msg)

    def init_ui(self):
        self.canvas = Canvas(self)
        layout = QVBoxLayout(self.ui.groupBoxCanvas)
        layout.addWidget(WindowCanvas(self.canvas))

        self.statusBar().addPermanentWidget(self.ui.progressBar)
        self.ui.progressBar.hide()

        self.ui.but_connect_server.setProperty("class", "connect")
        self.ui.but_open_camera.setProperty("class", "connect")

        self.ui.cbb_camera_id.addItems(get_camera_devices())
        self.ui.cbb_mode_handeye.currentIndexChanged.connect(self.on_current_index_changed_cbb_mode_handeye)
        self.ui.n_poses.valueChanged.connect(self.on_value_changed_n_poses)

        self.ui.but_grab.clicked.connect(self.on_clicked_but_grab)
        self.ui.but_calibration.clicked.connect(self.on_clicked_but_calib)
        self.ui.but_get_pose.clicked.connect(self.on_clicked_but_get_pose)
        self.ui.but_open_camera.clicked.connect(self.on_clicked_but_open_camera)
        self.ui.but_connect_server.clicked.connect(self.on_clicked_but_connect_server)
        self.ui.but_handeye.clicked.connect(self.on_clicked_but_handeye)

        self.showResultSignal.connect(self.show_result)
        self.showImageSignal.connect(self.show_image)
        self.updateRowSignal.connect(self.update_row)
        self.updatePoseSignal.connect(self.update_pose_to_table)
        self.showEffectSignal.connect(self.show_save_effect)
        self.hideEffectSignal.connect(self.hide_save_effect)
        self.logErrorSignal.connect(self.log_error)
        self.logInfoSignal.connect(self.log_info)
        self.logWarningSignal.connect(self.log_warning)
        self.showMessageBoxWarningSignal.connect(self.show_message_box_warning)
        self.showMessageQuestionSignal.connect(self.show_message_box_question)

        self.ui.actionSave.triggered.connect(lambda: self.save_config("res/config.json"))
        self.ui.actionExport_File.triggered.connect(self.on_clicked_but_export)
        self.ui.actionImport_File.triggered.connect(self.on_clicked_but_import)

        self.ui.actionSave.setIcon(newIcon("save"))
        self.ui.actionExport_File.setIcon(newIcon("export"))
        self.ui.actionImport_File.setIcon(newIcon("import"))

        # Add theme selection
        self.ui.actionDark_Mode.setCheckable(True)
        self.ui.actionLight_Mode.setCheckable(True)
        self.ui.actionOragne_Mode.setCheckable(True)

        self.ui.actionDark_Mode.triggered.connect(lambda: self.toggle_theme("dark"))
        self.ui.actionLight_Mode.triggered.connect(lambda: self.toggle_theme("light"))
        self.ui.actionOragne_Mode.triggered.connect(lambda: self.toggle_theme("orange"))

        self.toggle_theme("dark")  # Set default theme

        # Add context menu to listWidget
        self.ui.listWidget.setContextMenuPolicy(Qt.CustomContextMenu)
        self.ui.listWidget.customContextMenuRequested.connect(self.show_list_widget_context_menu)

        self.ui.tableWidget.setContextMenuPolicy(Qt.CustomContextMenu)
        self.ui.tableWidget.customContextMenuRequested.connect(self.show_table_widget_context_menu)

        # Add Help -> About action
        self.ui.actionAbout.triggered.connect(self.show_about_dialog)

        # Add version label to status bar
        version_label = QLabel(f"Version {VERSION}")
        version_label.setFrameStyle(QFrame.Panel | QFrame.Sunken)
        self.statusBar().addPermanentWidget(version_label)

        # Add progress bar for save effect
        self.save_progress_bar = QProgressBar(self)
        self.save_progress_bar.setMaximum(100)
        self.save_progress_bar.setValue(0)
        self.save_progress_bar.setFixedSize(300, 30)
        self.save_progress_bar.hide()

        # Add progress bar for load effect
        self.load_progress_bar = QProgressBar(self)
        self.load_progress_bar.setMaximum(100)
        self.load_progress_bar.setValue(0)
        self.load_progress_bar.setFixedSize(300, 30)
        self.load_progress_bar.hide()

    def on_current_index_changed_cbb_mode_handeye(self, index):
        self.ui.tableWidget.clearContents()
        self.ui.tableWidget.setRowCount(2*self.n_poses)

    def on_value_changed_n_poses(self, value):
        self.n_poses = value
        self.ui.tableWidget.setRowCount(2*self.n_poses)

    def check_camera_and_client_ready(self):
        if self.camera is None:
            msg = "Camera is not ready. Please open the camera first."
            self.logErrorSignal.emit(msg)
            logger.error(msg)
            return False
        if self.client is None:
            msg = "Client is not connected. Please connect to the robot first."
            self.logErrorSignal.emit(msg)
            logger.error(msg)
            return False
        return True

    def update_row(self, row, data):
        for col, value in enumerate(data):
            item = QTableWidgetItem(str(value))
            self.ui.tableWidget.setItem(row, col, item)

    def show_list_widget_context_menu(self, position):
        menu = QMenu()
        clear_action = QAction("Clear", self)
        clear_action.triggered.connect(self.ui.listWidget.clear)
        menu.addAction(clear_action)
        menu.exec_(self.ui.listWidget.viewport().mapToGlobal(position))

    def show_table_widget_context_menu(self, position):
        menu = QMenu()
        clear_action = QAction("Clear", self)
        clear_action.triggered.connect(self.ui.tableWidget.clearContents)
        menu.addAction(clear_action)
        menu.exec_(self.ui.tableWidget.viewport().mapToGlobal(position))

    def show_about_dialog(self):
        version_info = (
            f"Version {VERSION}\n\n"
            "HandEyeCalibrationTool is a tool for calibrating hand-eye coordination.\n\n"
            "Updates:\n"
            "- Added dark mode theme\n"
            "- Improved calibration accuracy\n"
            "- Fixed bugs in image processing\n"
            "- Added support for new camera models\n"
        )
        QMessageBox.about(self, "About HandEyeCalibrationTool", version_info)

    def toggle_theme(self, theme):
        if theme == "dark":
            load_style_sheet("res/style/dark_style.css", QApplication.instance())
        elif theme == "light":
            load_style_sheet("res/style/light_style.css", QApplication.instance())
        elif theme == "orange":
            load_style_sheet("res/style/orange_style.css", QApplication.instance())
        self.update_theme_actions(theme)

    def update_theme_actions(self, theme):
        self.ui.actionDark_Mode.setChecked(theme == "dark")
        self.ui.actionLight_Mode.setChecked(theme == "light")
        self.ui.actionOragne_Mode.setChecked(theme == "orange")

    def on_clicked_but_import(self):
        filename = get_file_name_dialog(self, "", "Pickle file(*.pkl)")
        if not filename:
            return
        self.calib_utils.load(filename)
        msg = "Load camera matrix success"
        self.logInfoSignal.emit(msg)
        logger.info(msg)

    def on_clicked_but_export(self):
        filename = get_save_file_name_dialog(self, "", "Pickle file(*.pkl)")
        if not filename:
            return
        os.makedirs("data", exist_ok=True)
        self.calib_utils.save("data/camera_matrix.pkl")
    
    def on_clicked_but_get_pose(self):
        if not self.check_camera_and_client_ready():
            return
        threading.Thread(target=self.thread_clicked_get_pose, daemon=True).start()

    def thread_clicked_get_pose(self):
        self.showEffectSignal.emit(3)
        pose_index = int(self.ui.cbb_pos_index.currentText())
        self.call_robot_move_to_pos(f"p{pose_index}")
        res = self.wait_for_robot_response()
        if res:
            row = 2*(pose_index-1)
            pose = self.get_camera_pose(self.mat)
            self.updatePoseSignal.emit(row, pose)

            pose = self.get_robot_pose()
            self.updatePoseSignal.emit(row+1, pose)
            self.hideEffectSignal.emit(100)
        else:
            msg = "Error getting pose"
            self.logErrorSignal.emit(msg)
            logger.error(msg)
            self.hideEffectSignal.emit(100)

    def update_pose_to_table(self, row, pose=None):
        if pose is not None:
            tx, ty, tz, rx, ry, rz = pose
            data = (tx, ty, tz, rx, ry, rz)
            self.update_row(row, data)

    def on_clicked_but_handeye(self):
        if not self.check_camera_and_client_ready():
            return
        # Add a message box question
        result = QMessageBox.question(self, "Confirmation", "Are you sure you want to run hand-eye calibration?", QMessageBox.Yes | QMessageBox.No)
        if result == QMessageBox.Yes:
            self.init_calib()
            if self.calib_utils._camera_matrix is not None:
                self.ui.but_handeye.setEnabled(False)

                mode = self.get_config().get("Calibration", {}).get("calib_mode", "Auto") # Auto or Manual
                if mode == "Manual":
                    threading.Thread(target=self.thread_clicked_handeye, args=(STEP_CALCULATE_MATRIX,), daemon=True).start()
                else:
                    self.count_pose = 0
                    threading.Thread(target=self.thread_clicked_handeye, args=(STEP_MOVE,), daemon=True).start()
            else:
                msg = "Camera matrix is not loaded. Please load the camera matrix or calibration camera first."
                self.logErrorSignal.emit(msg)
                logger.error(msg)
                QMessageBox.warning(self, "Error", msg)

    def thread_clicked_handeye(self, step_init=STEP_MOVE):
        step = step_init

        while True:
            try:
                if step == STEP_MOVE:
                    self.count_pose += 1
                    if self.count_pose > self.n_poses:
                        self.count_pose = 0
                        step = STEP_CALCULATE_MATRIX
                    
                    else:
                        self.call_robot_move_to_pos(f"p{self.count_pose}")
                        step = STEP_WAIT_MOVING

                elif step == STEP_WAIT_MOVING:
                    res = self.wait_for_robot_response()
                    if res:
                        step = STEP_GET_POSE
                    else:
                        step = STEP_ERROR
                
                elif step == STEP_GET_POSE:

                    self.showEffectSignal.emit(3)

                    row = 2 * (self.count_pose-1)

                    pose = self.get_camera_pose(self.mat)
                    if pose is None:
                        msg = f"Pos-{self.count_pose}: Cannot get camera pose"
                        self.logErrorSignal.emit(msg)
                        logger.error(msg)
                    else:
                        msg = f"Pos-{self.count_pose}: Get camera pose success"
                        self.logInfoSignal.emit(msg)
                        logger.info(msg)
                        self.updatePoseSignal.emit(row, pose)

                    pose = self.get_robot_pose()

                    if pose is None:
                        msg = f"Pos-{self.count_pose}: Cannot get robot pose"
                        self.logErrorSignal.emit(msg)
                        logger.error(msg)
                    else:
                        msg = f"Pos-{self.count_pose}: Get robot pose success"
                        self.logInfoSignal.emit(msg)
                        logger.info(msg)
                        self.updatePoseSignal.emit(row + 1, pose)

                    self.hideEffectSignal.emit(500)
                    step = STEP_MOVE

                elif step == STEP_ERROR:
                    msg = "Error in hand-eye calibration process"
                    self.logErrorSignal.emit(msg)
                    logger.error(msg)
                    self.hideEffectSignal.emit(300)
                    self.count_pose = 0
                    self.ui.but_handeye.setEnabled(True)
                    return
                
                elif step == STEP_CALCULATE_MATRIX:
                    self.showEffectSignal.emit(3)

                    poses = self.get_all_poses_from_table()
                    print(json.dumps(poses, indent=4))

                    if len(poses["camera"]) != len(poses["robot"]):
                        msg = "The number of camera poses and robot poses must be equal"
                        self.logErrorSignal.emit(msg)
                        logger.error(msg)
                        self.hideEffectSignal.emit(300)
                        self.ui.but_handeye.setEnabled(True)
                        return
                    
                    n_poses = int(self.get_config().get("Calibration", {}).get("n_poses", 5))
                    if len(poses["camera"]) < n_poses:
                        msg = f"The number of camera poses must be greater than or equal to {n_poses}"
                        self.logErrorSignal.emit(msg)
                        logger.error(msg)
                        self.hideEffectSignal.emit(300)
                        self.ui.but_handeye.setEnabled(True)
                        return

                    t_cam_to_gripper = self.calib_utils.calibration_handeye(poses)
                    print(t_cam_to_gripper)
                    self.calib_utils.save("data/camera_matrix.pkl")
                    
                    msg = "Calibration hand-eye success"
                    self.logInfoSignal.emit(msg)
                    logger.info(msg)
                    self.ui.but_handeye.setEnabled(True)
                    self.hideEffectSignal.emit(300)
                    return
                
            except Exception as ex:
                err = str(ex)
                self.logErrorSignal.emit(err)
                logger.error(err)
                return

            time.sleep(0.1)

    def get_all_poses_from_table(self):
        poses = {
            "camera": [],
            "robot": [] 
        }

        for i in range(self.ui.tableWidget.rowCount()):
            pose = []
            for j in range(self.ui.tableWidget.columnCount()):
                item = self.ui.tableWidget.item(i, j)
                if item is not None:
                    pose.append(float(item.text()))
            
            if len(pose) == 6:
                if i % 2 == 0:
                    poses["camera"].append(tuple(pose))
                else:
                    poses["robot"].append(tuple(pose))

        return poses

    def on_clicked_but_calib(self):
        result = QMessageBox.question(self, "Confirmation", "Are you sure you want to start the calibration process?", QMessageBox.Yes | QMessageBox.No)
        if result == QMessageBox.Yes:
            # Start the calibration process
            self.ui.but_calibration.setEnabled(False)
            try:
                checker_board_dir = "data/calib"
                n_image = len(self.calib_utils.get_paths(checker_board_dir))
                if n_image < 15:
                    msg = "Num images must be greater than or equal to 15"
                    self.logErrorSignal.emit(msg)
                    logger.error(msg)
                    QMessageBox.warning(self, "Error", msg)
                    self.ui.but_calibration.setEnabled(True)
                    return

                self.ui.progressBar.setRange(0, n_image + 1)

                board_size = tuple(map(int, self.ui.ln_board_size.text().split(",")))
                square_size = int(self.ui.ln_square_size.text())

                self.calib_utils.create(board_size, square_size)

                threading.Thread(target=self.calib_utils.find_camera_matrix_and_dist_coeffs,
                                    args=(checker_board_dir, ), daemon=True).start()
            except Exception as ex:
                msg = f"{ex}"
                self.logErrorSignal.emit(msg)
                self.ui.but_calibration.setEnabled(True)
                logger.error(msg)
                pass
        else:
            # Cancel the calibration process
            self.ui.but_calibration.setEnabled(True)

    def on_step_calib(self):
        self.ui.progressBar.setValue(self.ui.progressBar.value() + 1)

    def on_start_calib(self):
        self.ui.progressBar.show()
        self.ui.progressBar.setValue(0)

    def on_finished_calib(self):
        self.ui.progressBar.setValue(self.ui.progressBar.maximum())
        self.ui.progressBar.hide()
        self.ui.but_calibration.setEnabled(True)
    
    def on_clicked_but_grab(self):
        if not self.check_camera_and_client_ready():
            return
        self.show_save_effect()
        self.ui.but_grab.setEnabled(False)
        if self.mat is not None:
            threading.Thread(target=self.find_corners, daemon=True).start()
        QTimer.singleShot(500, self.save_progress_bar.hide)

    def connect_to_robot(self):
        self.ui.but_connect_server.setEnabled(False)
        try:
            config = self.get_config()
            host = config.get("Server", {}).get("host")
            port = int(config.get("Server", {}).get("port"))
            
            self.client = VsClient()
            # self.client.settimeout(5)
            error = self.client.connect_to_server(host, port)
            if error:
                self.logErrorSignal.emit(error)
                logger.error(error)
                self.ui.but_connect_server.setEnabled(True)
                self.client = None
            else:
                msg = f"Connected to robot at {host}:{port}"
                self.logInfoSignal.emit(msg)
                logger.info(msg)
                self.ui.but_connect_server.setProperty("class", "disconnect")
                self.style().unpolish(self.ui.but_connect_server)
                self.style().polish(self.ui.but_connect_server)
                self.ui.but_connect_server.setText("Disconnect")
                self.ui.but_connect_server.setEnabled(True)
        except Exception as e:
            msg = f"Error connecting to robot: {e}"
            self.logErrorSignal.emit()
            logger.error(msg)
            self.ui.but_connect_server.setEnabled(True)
            self.client = None
        
        self.hideEffectSignal.emit(200)

    def disconnect_from_robot(self):
        self.ui.but_connect_server.setEnabled(False)
        try:
            self.client.close()
            msg = "Disconnected from robot"
            self.logInfoSignal.emit(msg)
            logger.info(msg)
            self.ui.but_connect_server.setText("Connect")
            self.ui.but_connect_server.setProperty("class", "connect")
            self.style().unpolish(self.ui.but_connect_server)
            self.style().polish(self.ui.but_connect_server)
            self.client = None
        except:
            pass
        self.ui.but_connect_server.setEnabled(True)

    def wait_for_robot_response(self):
        response = True
        try:
            if self.client.recv_from_server() == "OK":
                msg = "Robot response: OK"
                self.logInfoSignal.emit(msg)
                logger.info(msg)
            else:
                msg = "Robot response: NG"
                self.logErrorSignal.emit(msg)
                logger.error(msg)
                response = False
        except Exception as e:
            msg = f"Error waiting for robot response: {e}"
            self.logErrorSignal.emit()
            logger.error(msg)
            response = False

        time.sleep(0.1)

        return response

    def call_robot_move_to_pos(self, pose):
        if isinstance(pose, str):
            pose_name = pose
            self.client.movej_(pose_name)
            msg = f"Move to position: {pose_name}"
            self.logInfoSignal.emit(msg)
            logger.info(msg)
        else:
            x, y, z = pose[:3]
            self.client.movej(x, y, z)
            msg = f"Move to position: {x}, {y}, {z}"
            self.logInfoSignal.emit(msg)
            logger.info(msg)
    
    def get_robot_pose(self):
        try:
            pose = self.client.get_pose()
            return pose
        except Exception as e:
            msg = f"Error getting robot pose: {e}"
            self.logErrorSignal.emit(msg)
            return None
    
    def get_camera_pose(self, mat):
        return self.calib_utils.get_camera_pose(mat)

    def find_corners_(self, mat):
        self.result = self.calib_utils.find_corners(mat)
    
    def find_corners(self, timeout=1):
        if self.mat is None:
            return
        
        t_start  = time.time()

        mat = self.mat.copy()
        threading.Thread(target=self.find_corners_, args=(mat, ), daemon=True).start()

        self.result = None

        while True:
            dt = time.time() - t_start

            if self.result is not None:
                break

            if dt > timeout:
                msg = "Timeout find corners"
                self.logErrorSignal.emit(msg)
                break

            time.sleep(0.01)

        if self.result.corners is not None:
            self.showResultSignal.emit(self.result)
            self.event_show.set()

            self.b_message_box = None
            self.showMessageQuestionSignal.emit("Are you sure you want to save the image?")

            while self.b_message_box is None:
                time.sleep(0.1)

            if self.b_message_box:
                data_dir = "data/calib"
                os.makedirs(data_dir, exist_ok=True)

                path = os.path.join(data_dir, time.strftime("%H%M%S.jpg"))
                cv2.imwrite(path, self.result.src)

            time.sleep(1)
            self.event_show.clear()
            self.event_stop_progress.set()
        else:
            msg = "Error finding corners"
            self.logErrorSignal.emit(msg)
        
        self.ui.but_grab.setEnabled(True)
        
    def show_result(self, result:RESULTCORNERS=None):
        if result is not None:
            self.show_image(result.dst)

    def show_image(self, mat=None):
        if mat is not None:
            self.canvas.load_pixmap(ndarray2pixmap(mat))

    def on_clicked_but_open_camera(self):
        if self.ui.but_open_camera.text() == "Open":
            self.showEffectSignal.emit(3)
            threading.Thread(target=self.open_camera, daemon=True).start()
        else:
            self.close_camera()

    def open_camera(self):
        self.ui.but_open_camera.setEnabled(False)
        config = {"id": self.ui.cbb_camera_id.currentText(), "feature": None}
        self.camera: HIK = eval(self.ui.cbb_camera_type.currentText())(config=config)
        if self.camera.open():
            self.event_stop_live.clear()
            self.camera.start_grabbing()
            self.ui.but_open_camera.setProperty("class", "disconnect")
            self.style().unpolish(self.ui.but_open_camera)
            self.style().polish(self.ui.but_open_camera)
            self.ui.but_open_camera.setText("Close")
            threading.Thread(target=self.start_camera, daemon=True).start()
            msg = "Camera opened"
            self.logInfoSignal.emit(msg)
            logger.info(msg)
        else:
            msg = "Error opening camera"
            self.logErrorSignal.emit(msg)
            logger.error(msg)
            self.camera = None

        self.hideEffectSignal.emit(300)
        self.ui.but_open_camera.setEnabled(True)

    def close_camera(self):
        self.ui.but_open_camera.setEnabled(False)
        self.event_stop_live.set()
        self.camera.stop_grabbing()
        self.camera.close()
        self.camera = None
        self.ui.but_open_camera.setText("Open")
        self.ui.but_open_camera.setProperty("class", "connect")
        self.style().unpolish(self.ui.but_open_camera)
        self.style().polish(self.ui.but_open_camera)
        self.ui.but_open_camera.setEnabled(True)

    def start_camera(self):
        while True:
            if self.event_stop_live.is_set():
                break

            ret, self.mat = self.camera.grab()
            if self.ui.ch_undistort.isChecked():
                self.mat = self.calib_utils.remap_and_crop(self.mat)
            if not self.event_show.is_set():
                if self.mat is not None:
                    self.showImageSignal.emit(self.mat)

            time.sleep(0.04)

        msg = "Camera closed"
        self.logInfoSignal.emit(msg)
        logger.info(msg)

    def on_clicked_but_connect_server(self):
        if self.ui.but_connect_server.text() == "Connect":
            self.showEffectSignal.emit(3)
            threading.Thread(target=self.connect_to_robot, daemon=True).start()
        else:
            threading.Thread(target=self.disconnect_from_robot, daemon=True).start()

    def log_error(self, msg):
        msg = time.strftime(f"%H:%M:%S {msg}")
        self.ui.listWidget.insertItem(0, msg)
        it = self.ui.listWidget.item(0)
        it.setForeground(Qt.red)

    def log_info(self, msg):
        msg = time.strftime(f"%H:%M:%S {msg}")
        self.ui.listWidget.insertItem(0, msg)

    def show_message_box_warning(self, msg):
        QMessageBox.warning(self, "Warning", msg)

    def show_message_box_question(self, msg):
        self.b_message_box = None
        self.b_message_box = QMessageBox.question(self, "Question", msg, QMessageBox.Yes|QMessageBox.No) == QMessageBox.Yes

    def log_warning(self, msg):
        msg = time.strftime(f"%H:%M:%S {msg}")
        self.ui.listWidget.insertItem(0, msg)
        it = self.ui.listWidget.item(0)
        it.setBackground(Qt.yellow)
        it.setForeground(Qt.black)

    def get_config(self):
        config = {}
        for i in range(self.ui.tabWidget.count()):
            tab = self.ui.tabWidget.widget(i)
            tab_name = self.ui.tabWidget.tabText(i)
            config[tab_name] = {}
            for groupbox in tab.findChildren(QGroupBox):
                for child in groupbox.children():
                    if isinstance(child, QLineEdit):
                        config[tab_name][child.placeholderText()] = child.text()
                    elif isinstance(child, QComboBox):
                        config[tab_name][child.placeholderText()] = child.currentText()
                    elif isinstance(child, QCheckBox):
                        config[tab_name][child.text().lower()] = child.isChecked()
                    elif isinstance(child, QSpinBox):
                        config[tab_name][child.objectName()] = child.value()
                    elif isinstance(child, QDoubleSpinBox):
                        config[tab_name][child.objectName()] = child.value()
        return config

    def set_config(self, config):
        for i in range(self.ui.tabWidget.count()):
            tab = self.ui.tabWidget.widget(i)
            tab_name = self.ui.tabWidget.tabText(i)
            if tab_name in config:
                for groupbox in tab.findChildren(QGroupBox):
                    for child in groupbox.children():
                        if isinstance(child, QLineEdit) and child.placeholderText() in config[tab_name]:
                            child.setText(config[tab_name][child.placeholderText()])
                        elif isinstance(child, QComboBox) and child.placeholderText() in config[tab_name]:
                            index = child.findText(config[tab_name][child.placeholderText()])
                            if index != -1:
                                child.setCurrentIndex(index)
                        elif isinstance(child, QCheckBox) and child.text() in config[tab_name]:
                            child.setChecked(config[tab_name][child.text()])
                        elif isinstance(child, QSpinBox) and child.objectName() in config[tab_name]:
                            child.setValue(config[tab_name][child.objectName()])
                        elif isinstance(child, QDoubleSpinBox) and child.objectName() in config[tab_name]:
                            child.setValue(config[tab_name][child.objectName()])

    def save_config(self, filename):
        self.show_save_effect()
        config = self.get_config()
        with open(filename, 'w') as file:
            json.dump(config, file, indent=4)
        self.statusBar().showMessage("Configuration saved!", 1000)
        QTimer.singleShot(500, self.save_progress_bar.hide)

    def show_save_effect(self, dt=3):
        self.save_progress_bar.setValue(0)
        self.save_progress_bar.move((self.width() - self.save_progress_bar.width()) // 2, (self.height() - self.save_progress_bar.height()) // 2)
        self.save_progress_bar.show()
        for i in range(1, 100):
            QTimer.singleShot(dt*i, lambda value=i: self.save_progress_bar.setValue(value))

    def hide_save_effect(self, timeout=500):
        QTimer.singleShot(10, lambda: self.save_progress_bar.setValue(100))
        QTimer.singleShot(timeout, self.save_progress_bar.hide)

    def load_config(self, filename):
        if os.path.exists(filename):
            with open(filename, 'r') as file:
                config = json.load(file)
                self.set_config(config)
                return config
        return {}
    
    def show_load_effect(self):

        self.load_progress_bar.setValue(0)
        self.load_progress_bar.move((self.width() - self.load_progress_bar.width()) // 2, (self.height() - self.load_progress_bar.height()) // 2)
        self.load_progress_bar.show()
        for i in range(1, 101):
            QTimer.singleShot(i * 2, lambda value=i: self.load_progress_bar.setValue(value))

    def closeEvent(self, event):
        reply = QMessageBox.question(self, 'Message', 
            "Are you sure you want to quit?", QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

        if reply == QMessageBox.Yes:
            if self.camera is not None:
                self.close_camera()
            self.save_config("res/config.json")
            event.accept()
        else:
            event.ignore()

if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    win = MainWindow()
    win.showMaximized()
    sys.exit(app.exec_())